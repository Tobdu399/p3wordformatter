This is a Python3 Word Formatter. Pwf can format any word to start with an
uppercase letter and the rest of the letters to be in lowercase. Feel free
to improvize my package as you like.

https://github.com/Tobdu399/p3wordformatter
https://github.com/Tobdu399/p3wordformatter.git
