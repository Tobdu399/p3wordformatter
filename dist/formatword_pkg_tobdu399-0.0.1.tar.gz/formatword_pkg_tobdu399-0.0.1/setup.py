import setuptools

with open("README.md", "r") as fh:
	long_description = fh.read()

setuptools.setup(
	name="formatword_pkg_tobdu399",
	version="0.0.1",
	author="Topias Niiranen",
	author_email="topias.j.m@gmail.com",
	description="Python3 Word Formatter",
	long_description=long_description,
	long_description_content_type="text/markdown",
	url="https://github.com/tobdu399/p3wordformatter",
	packages=setuptools.find_packages(),
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	],
)
